﻿using System;
using System.IO.Ports;
using System.Windows.Forms;

namespace _01BASIC
{
    public partial class winform : Form
    {
        private SerialPort serialPort = new SerialPort();

        public winform()
        {
            InitializeComponent();
            // 시리얼 포트 데이터 수신 이벤트 핸들러 등록
            serialPort.DataReceived += new SerialDataReceivedEventHandler(SerialPort_DataReceived);
        }

        private void PortNumber_SelectedIndexChanged(object sender, EventArgs e)
        {
            // 포트 선택 이벤트 처리
            ComboBox cb = (ComboBox)sender;
            Console.Write("Selected Idx : " + cb.SelectedIndex + "  ");
            Console.WriteLine("Selected Value : " + cb.Items[cb.SelectedIndex]);
        }

        private void conn_btn_Click(object sender, EventArgs e)
        {
            // 시리얼 포트 연결 버튼 클릭 이벤트 처리
            Console.WriteLine("Conn_Btn Click : " + this.PortNumber.Items[this.PortNumber.SelectedIndex].ToString());
            try
            {
                this.serialPort.PortName = this.PortNumber.Items[this.PortNumber.SelectedIndex].ToString();
                this.serialPort.BaudRate = 9600;
                this.serialPort.DataBits = 8;
                this.serialPort.StopBits = StopBits.One;
                this.serialPort.Parity = Parity.None;
                this.serialPort.Open();
                Console.WriteLine("CONNECTION SUCCESS");
                this.textArea.Text += "CONNECTION SUCCESS" + "\n";
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                this.serialPort.Close();
            }
        }

        private void SerialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            // 시리얼 데이터 수신 이벤트 핸들러
            String recvData = this.serialPort.ReadLine();
            Console.WriteLine(recvData);
            this.Invoke((MethodInvoker)delegate
            {
                // UI 스레드에서 UI 업데이트
                this.textArea.AppendText(recvData + "\r\n");
                // 데이터 파싱
                ParseSensorData(recvData);
            });
        }

        private void ParseSensorData(string data)
        {
            // 데이터 파싱 및 표시
            if (data.StartsWith("Celsius: "))
            {
                // 온도 데이터
                string temperature = data.Substring(9);
                tmp.Text = temperature;
            }
            else if (data.StartsWith("Illuminance: "))
            {
                // 광량 데이터
                string illuminance = data.Substring(13);
                light.Text = illuminance;
            }
            else if (data.StartsWith("Distance: "))
            {
                // 초음파 거리 데이터
                string distance = data.Substring(10);
                sound.Text = distance;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // 버튼1 클릭 이벤트 처리 (LED 켜기)
            try
            {
                this.serialPort.WriteLine("1");
                string response = this.serialPort.ReadLine();
                AppendReceivedData(response);
            }
            catch (Exception ex)
            {
                MessageBox.Show("FAILED TO ON LED: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // 버튼2 클릭 이벤트 처리 (LED 끄기)
            try
            {
                this.serialPort.WriteLine("0");
                string response = this.serialPort.ReadLine();
                AppendReceivedData(response);
            }
            catch (Exception ex)
            {
                MessageBox.Show("FAILED TO OFF LED: " + ex.Message);
            }
        }

        private void AppendReceivedData(string data)
        {
            // 수신 데이터를 텍스트 박스에 추가
            textArea.Text += data + "\n";
            Console.WriteLine(data);
        }
    }
}
